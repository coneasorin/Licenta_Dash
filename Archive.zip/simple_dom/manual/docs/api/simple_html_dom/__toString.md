# __toString

```php
__toString () : string
```

Returns the inner text of the root element of the DOM.