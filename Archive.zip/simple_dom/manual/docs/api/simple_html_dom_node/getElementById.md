# getElementById

```php
getElementById ( string $id ) : object
```

| Parameter | Description
| --------- | -----------
| `id`      | Element id.

Returns the first element with the specified id.